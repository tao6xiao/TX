package trs.com.cn.gov.kpi.service;

import trs.com.cn.gov.kpi.entity.User;

/**
 * Created by wangxuan on 2017/5/9.
 */
public interface UserService {

    User getUserById(int user);
}
