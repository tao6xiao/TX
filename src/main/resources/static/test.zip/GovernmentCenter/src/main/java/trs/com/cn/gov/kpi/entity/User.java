package trs.com.cn.gov.kpi.entity;

import lombok.Data;

/**
 * Created by wangxuan on 2017/5/9.
 */
@Data
public class User {

    private int id;

    private String name;
}
